import React, { useState } from 'react';
import PremiumHeader from './components/PremiumHeader';
import CinematicHero from './components/CinematicHero';
import AdoptionTinder from './components/AdoptionTinder';
import ProcessTimeline from './components/ProcessTimeline';
import ContactForm from './components/ContactForm';
import PremiumFooter from './components/PremiumFooter';

const App = () => {
  const [currentPage, setCurrentPage] = useState('inicio');

  const handleNavigate = (page) => {
    setCurrentPage(page);
    // Opcional: scroll suave a la sección
    const section = document.getElementById(page);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <PremiumHeader onNavigate={handleNavigate} />
      <main className="flex-grow">
        {/* Renderizado condicional de secciones */}
        {currentPage === 'inicio' && <CinematicHero onNavigate={handleNavigate} />}
        {currentPage === 'adopta' && <AdoptionTinder onNavigate={handleNavigate} />}
        {currentPage === 'proceso' && <ProcessTimeline onNavigate={handleNavigate} />}
        {currentPage === 'contacto' && <ContactForm />}
        {/* Puedes añadir más secciones aquí y sus botones de navegación */}
        {/* Por ejemplo, para 'Historias': */}
        {/* {currentPage === 'historias' && <HappyStories />} */}
      </main>
      <PremiumFooter />
    </div>
  );
};

export default App;

// DONE